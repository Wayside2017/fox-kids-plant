#!/usr/bin/env python3
"""24/7 schedule-driven FFmpeg playout to a private MediaMTX RTMP ingest."""
import json, os, subprocess, time
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
MEDIA_ROOT = ROOT / "media"
SCHEDULE_FILE = ROOT / "schedule.json"
TZ = ZoneInfo(os.getenv("CHANNEL_TIMEZONE", "America/Chicago"))
RTMP_URL = os.getenv("RTMP_URL", "rtmp://mediamtx:1935/fkp")
SLATE = MEDIA_ROOT / "foxkidsplant-slate.mp4"


def load_schedule():
    data = json.loads(SCHEDULE_FILE.read_text(encoding="utf-8"))
    entries = sorted(data["schedule"], key=lambda x: int(x["start_minute"]))
    if not entries:
        raise RuntimeError("schedule.json contains no schedule entries")
    return entries


def current_slot(entries, now):
    minute = now.hour * 60 + now.minute
    chosen = entries[-1]
    for entry in entries:
        if int(entry["start_minute"]) <= minute:
            chosen = entry
        else:
            break
    next_start = next((int(e["start_minute"]) for e in entries if int(e["start_minute"]) > minute), 1440)
    seconds_into = (minute - int(chosen["start_minute"])) * 60 + now.second
    slot_seconds = max(60, (next_start - int(chosen["start_minute"])) * 60)
    remaining = max(1, slot_seconds - seconds_into)
    return chosen, seconds_into, remaining


def play(entry, offset, duration):
    relative = entry.get("file", "")
    candidate = (ROOT / relative).resolve() if relative else SLATE
    # Only explicitly rights-cleared assets may enter the channel output.
    if entry.get("rights_cleared") is not True or not candidate.is_file():
        candidate = SLATE
        title = "FOX Kids Plant — Test Slate / Rights-cleared media required"
        offset = 0
    else:
        title = entry.get("title", "Scheduled programme")
    print(f"[{datetime.now(TZ).isoformat()}] PLAY: {title} ({duration}s)", flush=True)
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "warning", "-re", "-stream_loop", "-1",
        "-i", str(candidate), "-ss", str(offset), "-t", str(duration),
        "-map", "0:v:0", "-map", "0:a:0?",
        "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30",
        "-c:v", "libx264", "-preset", "veryfast", "-tune", "zerolatency",
        "-b:v", "2500k", "-maxrate", "2800k", "-bufsize", "5000k",
        "-g", "60", "-keyint_min", "60", "-sc_threshold", "0",
        "-c:a", "aac", "-b:a", "128k", "-ar", "48000", "-ac", "2",
        "-f", "flv", RTMP_URL
    ]
    subprocess.run(cmd, check=False)


def main():
    if not SLATE.exists():
        raise SystemExit("Missing stream/media/foxkidsplant-slate.mp4")
    print(f"FOX Kids Plant playout starting; timezone={TZ}; output={RTMP_URL}", flush=True)
    while True:
        try:
            entries = load_schedule()
            now = datetime.now(TZ)
            entry, offset, remaining = current_slot(entries, now)
            play(entry, offset, remaining)
        except Exception as exc:
            print(f"Playout warning: {exc}; retrying with slate", flush=True)
            play({"title": "Station slate", "file": "media/foxkidsplant-slate.mp4", "rights_cleared": True}, 0, 60)
        time.sleep(2)

if __name__ == "__main__":
    main()

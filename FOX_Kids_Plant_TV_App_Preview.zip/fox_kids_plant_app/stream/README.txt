FOX KIDS PLANT — 24/7 INTERNET TV STARTER

WHAT THIS ADDS
- A 24/7 schedule-driven FFmpeg playout process.
- MediaMTX RTMP ingest and HLS output.
- A public HLS live player at /live.html.
- Caddy HTTPS for a domain you control.
- A station slate so the pipeline can be tested before programme rights are cleared.

IMPORTANT: THIS PACKAGE IS NOT YET A PUBLIC BROADCAST
The included video is an original FOX Kids Plant test slate, not a TV episode. The schedule deliberately loops this slate. Do not add copyrighted episodes unless the channel has written permission covering internet streaming, territory, term, and any music/clip rights. Streaming services such as Tubi, Roku Channel and Prime Video cannot simply be rebroadcast through this system.

DEPLOYMENT (a responsible adult/server administrator should do this)
1. Rent a Linux VPS with Docker Compose, a public IPv4 address, and enough bandwidth. For a 2.5 Mbps 720p stream, budget roughly 1.1 GB per viewer-hour; 100 simultaneous viewers can require about 250 Mbps outbound. CDN delivery is recommended beyond a small test.
2. Register or use a domain you control. Point its DNS A record to the VPS IP. Do not use a domain you do not own.
3. Copy this whole app folder to the server. In stream/, copy .env.example to .env and set DOMAIN to your real domain.
4. Open TCP ports 80 and 443 on the server firewall. Keep RTMP port 1935 and MediaMTX HLS port 8888 private; the compose file does not publish them publicly.
5. From stream/, run: docker compose up -d --build
6. Visit https://YOUR-DOMAIN/live.html. It should play the original station slate once Docker reports all services running.
7. View logs with: docker compose logs -f playout mediamtx web
8. Stop with: docker compose down

ADDING A RIGHTS-CLEARED PROGRAMME
- Put an MP4 file in stream/media/ (H.264 video + AAC audio, 720p recommended).
- Edit stream/schedule.json. Each entry starts at a local minute after midnight (0 to 1439). Use a 30-minute slot cadence for the supplied schedule.
- Set file to e.g. media/programme-01.mp4, set a descriptive title and block, and set rights_cleared to true ONLY after the channel operator has verified written streaming rights for that exact asset.
- The playout service loops each selected file to fill its slot. If the file is missing or rights_cleared is not true, it outputs the station slate instead.
- Rebuild after adding media: docker compose up -d --build playout

OPERATIONS / SAFETY
- Use a CDN or managed streaming provider for scale; a single VPS is not a resilient broadcast facility.
- Set up backups, monitoring, security updates, a privacy notice, moderation/contact process, and a takedown contact before public launch.
- Obtain adult assistance for hosting contracts, domain registration, payments, and rights-holder agreements.
- This starter is not independently audited for production security, accessibility, broadcast compliance, or high availability.

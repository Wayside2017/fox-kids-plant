FOX KIDS PLANT — WEBSITE + 24/7 INTERNET TV STARTER

Open index.html for the channel website. Open live.html for the live HLS player.
The stream infrastructure, schedule, and deployment instructions are in stream/README.txt.

The included 30-second station slate is original test material. It verifies that the playout server, RTMP ingest, HLS packaging, HTTPS website, and player can work together. It is NOT a programme library and the package is not already deployed or broadcasting publicly.

A real public channel requires a server, a domain with DNS/HTTPS, bandwidth/CDN, ongoing operation, and written streaming rights for every programme. The schedule will output the slate whenever a scheduled file is missing or not marked rights-cleared.

To deploy, follow stream/README.txt. Do not expose the RTMP ingest or MediaMTX HLS origin directly to the public internet.

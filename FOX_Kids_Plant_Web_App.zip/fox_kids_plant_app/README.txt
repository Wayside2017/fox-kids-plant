FOX KIDS PLANT — WEBSITE + INSTALLABLE WEB APP

CONTENTS
- index.html: the website and streaming-block guide
- manifest.webmanifest: installable app metadata
- service-worker.js: offline app-shell caching
- fox-kids-plant-icon.svg: app icon

HOW TO PUBLISH
1. Upload all four files (keep their filenames) to a static website host such as Netlify, Cloudflare Pages, or GitHub Pages.
2. Connect a domain you own, such as foxkidsplant.org, using the host's domain/DNS instructions.
3. Enable HTTPS. Service workers and PWA installation require a secure origin (localhost is the development exception).
4. Open the HTTPS website on a supported browser. On Android, choose Install app/Add to Home Screen. On iPhone/iPad, open in Safari, tap Share, then Add to Home Screen.

IMPORTANT LIMITATIONS
- This package is a Progressive Web App (PWA), not a native iOS/Android store binary. Native store publication requires separate platform packaging, developer accounts, review, and compliance.
- The schedule and programme guide are sample editorial listings, not a live broadcast feed.
- Roku Channel, Tubi, and Prime Video are external provider destinations. This app does not embed or rebroadcast their catalogues. Provider availability varies by title and region.
- You need rights-holder permission or a formal distribution agreement to stream copyrighted episodes directly in FOX Kids Plant.
- The domain foxkidsplant.org is not registered, connected, or published by this package.

# FOX Kids Plant — Android app source (preview)

This is an Android Studio project for a first Android phone/tablet version of FOX Kids Plant. It wraps the existing TV-friendly web interface in an Android WebView and opens `tv.html` as the home screen.

## What works in this preview
- Android launcher app named **FOX Kids Plant**
- Home screen, sample TV guide, website navigation and live-player screen
- Back navigation inside the app
- External provider links open in the device browser
- Clear notice when the live broadcast has not been hosted

## What is not ready yet
- This is source code, not a signed APK or Play Store release.
- The live channel is not online. The player intentionally reports that the feed is not hosted yet when opened from the local app preview.
- A public release needs a hosted HTTPS website/stream, streaming rights for every programme, device testing, a signed release build, and Google Play review.

## Build with Android Studio
1. Install Android Studio on a computer and its recommended Android SDK (API 35) and JDK 17.
2. Open this folder (`FOX_Kids_Plant_Android_App`) as an existing project.
3. Let Android Studio sync Gradle. If prompted, accept the compatible Gradle/Android plugin setup.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)** to create a local test APK.
5. Test on an Android phone/tablet or emulator.

No domain or hosting is needed to preview the app interface. A public live stream does require a domain/server and HTTPS. When the domain is ready, point the live player at the real HLS playlist and use the hosted site for production.

## Important content rule
Only stream programmes that are original, public-domain, or covered by written licences that include internet and app distribution rights. Links to third-party services are not permission to rebroadcast their programmes.

A responsible adult should handle developer-account registration, contracts, hosting payments, and publishing submissions.

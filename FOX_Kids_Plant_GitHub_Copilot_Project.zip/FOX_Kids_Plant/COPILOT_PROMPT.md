# GitHub Copilot task: finish FOX Kids Plant

Inspect this repository before changing anything. The current `index.html` is the existing FOX Kids Plant website prototype. Keep its branding and working features, then improve it into a polished, accessible, responsive static website.

Requirements:
- Keep the FOX Kids Plant name and on-screen channel identity.
- Keep and improve the programme catalogue, network filters, search, programme details, schedule, and provider links.
- Make every control functional and test the site at phone, tablet, and desktop widths.
- Clearly label sample schedules as samples; do not claim a real broadcast is live.
- Provider links must go to legitimate provider pages. Do not claim a show is available unless verified.
- Do not host, copy, embed, or distribute copyrighted episodes without permission. Use only authorized trailers or videos.
- Do not add fake login, payment, streaming, or account functionality.
- Keep the project deployable as a static site on GitHub Pages or another static host.
- Preserve the PWA manifest, icons, and service worker; check that paths work from a subfolder as well as the domain root.
- Add clear README instructions for local preview and deployment.
- Do not add paid APIs or expose secrets.
- Test links, search, filters, schedule interactions, accessibility labels, and browser console errors.

This is an independent fan-made guide and is not affiliated with FOX or the other listed networks. Build and test the actual code, not just a plan.

FOX KIDS PLANT — WEBSITE PACKAGE

MAIN FILE
- index.html: the current expanded FOX Kids Plant website prototype.

OTHER FILES
- manifest.webmanifest and icons: allow supported browsers to offer an installable app experience.
- service-worker.js: caches the basic site shell for limited offline access.
- fox-kids-plant-icon.svg: site/app icon.

RUN LOCALLY
1. Extract this ZIP.
2. Open index.html in a modern browser to preview the website.
3. For full installable-app/service-worker behavior, publish it on an HTTPS host.

PUBLISH
Upload the CONTENTS of this folder to the public web root of a static hosting service.
For a /home/ address, place the files in the hosting folder that maps to /home/.
The correct folder depends on the hosting provider.

IMPORTANT LIMITATIONS
- This is an independent fan-made programme guide, not an official broadcaster website.
- Sample schedules are demonstrations, not live broadcast schedules.
- Streaming-service links lead to provider sites; availability varies by region and account.
- No copyrighted full episodes are included. Only use videos you own or are authorized to publish.
- The package does not include a server, database, user accounts, or a live TV feed.
- Keep personal information and passwords out of public repository files.
